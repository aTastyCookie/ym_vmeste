<?php
class ICPDO {
	public $server = "";
	public $db = "";
	public $user = "";
	public $password = "";
	public $prefix = "";
	public $insert_id;
	public $link;
	
	public function __construct($_server, $_db, $_user, $_password, $_prefix) {
		$this->server = $_server;
		$this->db = $_db;
		$this->user = $_user;
		$this->password = $_password;
		$this->prefix = $_prefix;
		$this->link = new PDO('mysql:host='.$this->server.';dbname='.$this->db,
								$this->user, $this->password, 
								array( PDO::ATTR_PERSISTENT => true));
	}
	
	public function get_row($_sql) {
		$sth = $this->link->prepare($_sql);
		$sth->execute();
		return $sth->fetch();
	}
	
	public function get_rows($_sql) {
		$sth = $this->link->prepare($_sql);
		$sth->execute();
		return $sth->fetchAll();
	}
	
	public function get_var($_sql) {
		$sth = $this->link->prepare($_sql);
		$sth->execute();
		$row = $sth->fetch(PDO::FETCH_NUM);
		if ($row && is_array($row)) return $row[0];
		return false;
	}
	
	public function query($_sql) {
		$sth = $this->link->prepare($_sql);
		$sth->execute();
		$result = $sth->fetchAll();
		$this->insert_id = $this->link->lastInsertId();
		return $result;
	}
}
?>