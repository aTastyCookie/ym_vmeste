<?php
include_once(dirname(__FILE__).'/inc/config.php');
include_once(dirname(__FILE__).'/inc/settings.php');
include_once(dirname(__FILE__).'/inc/icpdo.php');
include_once(dirname(__FILE__).'/inc/functions.php');

$icpdo = new ICPDO(DB_HOST, DB_NAME, DB_USER, DB_PASSWORD, TABLE_PREFIX);
get_options();
//var_dump($options);
if(!isset($_GET['id']) || empty($_GET['id'])) die("Campaign ID is required");
$id = (int)$_GET['id'];
$campaign = $icpdo->get_row("SELECT * FROM ".$icpdo->prefix."campaigns WHERE id = $id LIMIT 1;");
if(!$campaign || empty($campaign)) die('Campaign does not exist'); 
if($campaign['deleted'] == 1) die('Campaign is deleted'); 
if($campaign['status'] == 0) die('Campaign is blocked'); 

?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8"/>
  <title><?php echo $campaign['title']?></title>
  <link rel="stylesheet" href="css/font.css"/>
  <link rel="stylesheet" href="css/styles.css"/>
  <script src="js/libs/jquery-2.1.1.min.js"></script>
  <script src="js/app.js"></script>
</head>
<body>
<header>
  <div class="content">
    <h1><?php echo $campaign['title']?></h1>
    <div class="logo"></div>
  </div>
</header>
<div class="line"></div>
<div class="content">
  <h2>Мы собираем деньги ...</h2>
  <p>
  <?php echo $campaign['form_intro']?>
    <a href="#" class="more">Подробнее</a>
  </p>
  <div class="large_img">
    <img src="<?php echo $campaign['image']?>">
  </div>
  <div class="line"></div>
  <h2>Ваша помощь проекту</h2>
</div>
<form method="POST" enctype="application/x-www-form-urlencoded" action="<?php echo YANDEX_PAYMENT_URL;?>">
<input name="shopId" value="<?php echo $options['yandex_shopid']?>" type="hidden"/>
<input name="scid" value="<?php echo $options['yandex_scid']?>" type="hidden"/>
<input name="customerNumber" value="<?php echo time();?>" type="hidden"/>
<input name="noIDcustomerNumber" value="<?php echo time();?>" type="hidden"/>
<input name="orderNumber" value="<?php echo $campaign['id']?>" type="hidden"/>
  <div class="amount">
    <div class="content">
      <input type="text" class="value" placeholder="сумма" 
      		value="<?php echo $campaign['min_amount']?>" name="sum" required />
      <p class="rouble_sign">
        <span class="rur">p<span>уб.</span></span>
      </p>
      <select class="times" id="times" name="rebillingOn">
        <option value="0">отправить один раз</option>
        <option value="1">отправлять каждый месяц</option>
      </select>
    </div>
  </div>
  <div class="content">
    <div class="user_form">
	      <div class="fields">
	        <div class="item">
	          <label for="fio">Имя и фамилия</label>
	          <input type="text" id="fio" required />
	        </div>
	        <div class="item">
	          <label for="email">Email</label>
	          <input type="text" id="email" required>
	        </div>
	        <div class="clearfix"></div>
	      </div>
	      <div class="fields comment" style="display: none;">
	        <div class="item">
	          <label for="comment">Комментарий</label>
	          <textarea id="comment" placeholder="При желании вы можете указать, на что именно переводите деньги."></textarea>
	        </div>
	        <div class="clearfix"></div>
	      </div>
	      <div class="add_comment_box">
	        <a href="#" id="add_comment">Добавить комментарий</a>
	        <a href="#" id="remove_comment">Убрать комментарий</a>
	      </div>
    </div>
    <div class="line"></div>
    <h2>Способ перевода</h2>
    <div class="payment_options" id="payment_options">
      <input type="radio" id="yd_option" name="paymentType" value="PC">

      <div class="item">
        <label for="yd_option">
          <i class="yd"></i>
          <p>Яндекс.Деньги</p>
          <span>платеж со счета или банковской карты</span>
        </label>
        <div class="over"></div>
      </div>
      <input type="radio" id="nalik_option" name="paymentType" value="GP">

      <div class="item">
        <label for="nalik_option">
          <i class="nalik"></i>
          <p>Наличные</p>
          <span>через терминалы и салоны связи</span>
        </label>
        <div class="over"></div>
      </div>
      <input type="radio" id="bc_option" name="paymentType" value="AC">

      <div class="item" data-over="monthly">
        <label for="bc_option">
          <i class="bc"></i>
          <p>Банковская карта</p>
          <span>VISA, MasterCard, Maestro</span>
        </label>
        <div class="over"></div>
      </div>
      <input type="radio" id="wm_option" name="paymentType" value="WM">

      <div class="item">
        <label for="wm_option">
          <i class="wm"></i>
          <p>WebMoney</p>
          <span>с рублевого WM-кошелька</span>
          </label>
        <div class="over"></div>
      </div>
      <input type="radio" id="mobile_option" name="paymentType" value="MC">

      <div class="item">
        <label for="mobile_option">
          <i class="mobile"></i>
          <p>Счет мобильного телефона</p>
          <span>МТС, Билайн, Мегафон</span>
        </label>
        <div class="over"></div>
      </div>
      <div class="clearfix"></div>
    </div>
  </div>
  <div class="line"></div>
  <div class="content">
    <div class="make_donation">
      <button type="submit" class="btn yellow">Перевести</button>
    </div>
  </div>
</form>
<footer>
  <div class="share">
    <span>Поделиться в сетях:</span><a href="#" class="fb"></a><a href="#" class="vk"></a><a href="#" class="twit"></a>
  </div>
</footer>
</body>
</html>
