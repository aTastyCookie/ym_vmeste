<?php
include_once(dirname(__FILE__).'/inc/config.php');
include_once(dirname(__FILE__).'/inc/settings.php');
include_once(dirname(__FILE__).'/inc/icpdo.php');
include_once(dirname(__FILE__).'/inc/functions.php');
$icpdo = new ICPDO(DB_HOST, DB_NAME, DB_USER, DB_PASSWORD, TABLE_PREFIX);

// Add image column into campaigns
// 01/09/2014
$table = $icpdo->prefix."campaigns";
$migration = "Add image column into $table<br>";
$column = $icpdo->get_row("SHOW COLUMNS FROM $table WHERE Field like 'image';");
if(!$column || empty($column)) {
	echo $migration;
	$icpdo->query("ALTER TABLE $table 
					ADD COLUMN `image` VARCHAR(512) NULL DEFAULT '' AFTER `title`;");
} else echo "Skipping $migration";
echo ".........................................<br>";

// Null column in donors
// 01/09/2014
$table = $icpdo->prefix."donors";
$migration = "Null column in donors<br>";
$column = $icpdo->get_row("SHOW COLUMNS FROM $table WHERE Field like 'url';");
if($column && $column['Null'] == 'NO') {
	echo $migration;
	$icpdo->query("ALTER TABLE $table
					CHANGE COLUMN `url` `url` VARCHAR(255) 
					CHARACTER SET 'utf8' COLLATE 'utf8_unicode_ci' NULL DEFAULT '' ;");
} else echo "Skipping $migration";
echo ".........................................<br>";

// Users
// 08/09/2014
$migration = "user_id in ";
$tables = array($icpdo->prefix.'donors', 
				$icpdo->prefix.'campaigns', 
				$icpdo->prefix.'sessions', 
				$icpdo->prefix.'transactions', 
				$icpdo->prefix.'options');
foreach($tables as $table) {
	$column = $icpdo->get_row("SHOW COLUMNS FROM $table WHERE Field like 'user_id';");
	if($column || empty($column)) {
		echo $migration.$table.'<br>';
		$icpdo->query("ALTER TABLE $table
						ADD COLUMN `user_id` INT(11) UNSIGNED NOT NULL DEFAULT '1' AFTER `id`;");
	} else echo "Skipping $migration $table <br>";
}
echo ".........................................<br>";

$migration = "New table Users<br>";
$table = $icpdo->prefix."users";
if($icpdo->get_var("SHOW TABLES LIKE '".$table."'") != $table) {
	$sql = "CREATE TABLE IF NOT EXISTS ".$table." (
		id int(11) UNSIGNED NOT NULL  AUTO_INCREMENT,
		email varchar(255) COLLATE utf8_unicode_ci NOT NULL,
		password varchar(255) COLLATE utf8_unicode_ci NOT NULL,
		activation_key varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
		status int(1) NOT NULL DEFAULT '0',
		registered int(11) UNSIGNED NOT NULL ,
		UNIQUE KEY id (id)
	) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
	$icpdo->query($sql);
} else echo "Skipping $migration";
echo ".........................................<br>";
?>