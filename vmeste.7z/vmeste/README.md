vmeste
======

настройки для подключения к бд в inc/config.php
