<?php

namespace Vmeste\SaasBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class VmesteSaasBundle extends Bundle
{
}
