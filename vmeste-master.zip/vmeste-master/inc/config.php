<?php
define('DB_NAME', 'devnew');
define('DB_USER', 'root');
define('DB_PASSWORD', '7d4076ef2dQW');
define('DB_HOST', 'localhost');
?>