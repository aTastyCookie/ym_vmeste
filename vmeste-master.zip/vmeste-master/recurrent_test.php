<?php
include_once(dirname(__FILE__).'/inc/config.php');
include_once(dirname(__FILE__).'/inc/settings.php');
include_once(dirname(__FILE__).'/inc/icpdo.php');
include_once(dirname(__FILE__).'/inc/functions.php');
include_once(dirname(__FILE__).'/lib/Recurrent.php');
$icpdo = new ICPDO(DB_HOST, DB_NAME, DB_USER, DB_PASSWORD, TABLE_PREFIX);

$params = array(
			'url' => "https://penelope-demo.yamoney.ru:8083/webservice/mws/api/repeatCardPayment",
			'path_to_cert' => "/vmeste/pbl.cer",
			'path_to_key' => "/vmeste/private.key",
			'cert_pass' => "",
			'icpdo' => $icpdo,
			);
$recurrent = new Recurrent($params);

if (isset($_GET['uninstall'])) $recurrent->uninstall();
if (isset($_GET['install'])) $recurrent->install();
if (isset($_GET['reinstall'])) {
	$recurrent->uninstall();
	$recurrent->install();
}

$recurrent->notify();
$recurrent->run();
?>